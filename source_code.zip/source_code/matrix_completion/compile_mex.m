cd Auxiliary

% compute a subset entries of matrix product
mex partXY.c

% update a sparse matrix 
mex updateSval.c

cd ..