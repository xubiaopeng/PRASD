clear all;
clc;
close all;

total_run_num=10; % number of independent runs you want to run for one protein.
addpath(genpath('code'));
addpath('hanso');
addpath('tt');
addpath(genpath('matrix_completion'));
addpath(genpath('proteins'));
load 'ainfo.mat'

% Number of BFGS iterations
gd_tol  = 10^-9;
cg_iter = 500;
f = [10 10 10 10 10]; % [f_hb, f_tau, f_tal, f_vdw, f_tas]



fprintf('==========================================================================\n')


 protein_name_cell={'1g6j','1b4r','2k62','1cn7','2k49','2l3o','2gjy','2k7h','2yt0','2l7b'};

 for protein_i=1:10
     
protein_name=protein_name_cell{protein_i};

tstart=tic;
   

in_hbond_file = '';
in_max_res = [];
in_min_res = [];

switch protein_name
    case '1g6j'
        in_seq_file   = '1g6j.seq';
        in_upl_file   = {'1g6j.upl'};
        in_ang_file   = '1g6j.aco';
    case '1cn7'
        in_seq_file = '1cn7.seq';
        in_upl_file = {'1cn7.upl'};
        in_ang_file = '1cn7.aco';
        in_min_res = 2;
        in_max_res = 105;        
    case '2k7h'
        in_seq_file = '2k7h.seq';
        in_upl_file = {'2k7h2.upl','2k7h.upl'};
        in_ang_file = '2k7h.aco';
    case '2kte'
        in_seq_file = '2kte.seq';
        in_upl_file = {'2kte.upl'};
        in_ang_file = '2kte.aco';
    case '1b4r'
        in_seq_file = '1b4r.seq';
        in_upl_file = {'1b4r.upl'};
        in_ang_file = '1b4r.aco';
        in_min_res = 8;
        in_max_res = 87;        
    case '2k49'
        in_seq_file = '2k49.seq';
        in_upl_file = {'2k49.upl'};
        in_ang_file = '2k49.aco';
    case '2k62'
        in_seq_file = '2k62.seq';
        in_upl_file = {'2k62.upl'};
        in_ang_file = '2k62.aco';
    case '2gjy'
        in_seq_file = '2gjy.seq';
        in_upl_file = {'2gjy.upl'};
        in_ang_file = '2gjy.aco';        
    case '2yt0'
        in_seq_file = '2yt0.seq';
        in_upl_file = {'2yt0.upl'};
        in_ang_file = '2yt0.aco';
    case '2l7b'
        in_seq_file = '2l7b.seq';
        in_upl_file = {'2l7b.upl'};
        in_ang_file = '2l7b.aco';
    case '2e8o'
        in_seq_file = '2e8o.seq';
        in_upl_file = {'2e8o.upl'};
        in_ang_file = '2e8o.aco';        
    case '2l3o'
        in_seq_file = '2l3o.seq';
        in_upl_file = {'2l3o.upl'};
        in_ang_file = '2l3o.aco';
        in_min_res = 33;
        in_max_res = 156;
    case '2mz7'
        in_seq_file = '2mz7.seq';
        in_upl_file = {'2mz7.upl'};
        in_ang_file = '2mz7.aco';
        in_min_res = 267;
        in_max_res =312;
     case '1bc4'
        in_seq_file   = '1bc4.seq';
        in_upl_file   = {'1bc42.upl','1bc4.upl'};
        in_ang_file   = '';
        in_min_res = 2;
        in_max_res = 111;
     case '1beg'
        in_seq_file = '1beg.seq';
        in_upl_file = {'1beg.upl'};
        in_ang_file = '1beg.aco';
     case '1bfy'
        in_seq_file = '1bfy.seq';
        in_upl_file = {'1bfy.upl'};
        in_ang_file = '';
    case '1blr'
        in_seq_file='1blr.seq';
        in_upl_file={'1blr2.upl','1blr.upl'}; 
        in_ang_file='';
    case '1cey'
        in_seq_file='1cey.seq';
        in_upl_file={'1cey2.upl','1cey.upl'};
        in_ang_file='1cey.aco';
    case '1cfc'
        in_seq_file='1cfc.seq';
        in_upl_file={'1cfc2.upl','1cfc.upl'};
        in_ang_file='';
    case '1cir'
        in_seq_file='1cir.seq';
        in_upl_file={'1cir2.upl','1cir.upl'};
        in_ang_file='1cir.aco';
    case '1crp'
        in_seq_file='1crp.seq';
        in_upl_file={'1crp2.upl','1crp.upl'};
        in_ang_file='1crp.aco';
    case '1d3z'
        in_seq_file='1d3z.seq';
        in_upl_file={'1d3z2.upl','1d3z.upl'};
        in_ang_file='1d3z.aco';
    case '1eq0'
        in_seq_file='1eq0.seq';
        in_upl_file={'1eq0.upl'};
        in_ang_file='';
    case '1fdm';
        in_seq_file='1fdm.seq';
        in_upl_file={'1fdm2.upl','1fdm.upl'};
        in_ang_file='1fdm.aco';
    case '1fr0'
        in_seq_file   = '1fr0.seq';
        in_upl_file   = {'1fr02.upl','1fr0.upl'};
        in_ang_file   = '1fr0.aco';
        in_min_res = 654;
        in_max_res = 778;
    case '1gb1'
        in_seq_file   = '1gb1.seq';
        in_upl_file   = {'1gb12.upl','1gb1.upl'};
        in_ang_file   = '1gb1.aco';
    case '1go0'
        in_seq_file = '1go0.seq';
        in_upl_file = {'1go0.upl'};
        in_ang_file = '1go0.aco';
    case '1h0t'
        in_seq_file = '1h0t.seq';
        in_upl_file = {'1h0t2.upl','1h0t.upl'};
        in_ang_file = '1h0t.aco';
    case '1hfg'
        in_seq_file='1hfg.seq';
        in_upl_file={'1hfg2.upl','1hfg.upl'}; 
        in_ang_file='1hfg.aco';
    case '1iyy'
        in_seq_file='1iyy.seq';
        in_upl_file={'1iyy2.upl','1iyy.upl'};
        in_ang_file='';
    case '1jnj'
        in_seq_file='1jnj.seq';
        in_upl_file={'1jnj.upl'};
        in_ang_file='';
    case '1jok'
        in_seq_file='1jok.seq';
        in_upl_file={'1jok2.upl','1jok.upl'};
        in_ang_file='1jok.aco';
    case '1jv8'
        in_seq_file='1jv8.seq';
        in_upl_file={'1jv8.upl'};
        in_ang_file='1jv8.aco';
    case '1k3g'
        in_seq_file='1k3g.seq';
        in_upl_file={'1k3g.upl'};
        in_ang_file='';
        in_min_res = 22;
        in_max_res = 92;  
    case '1k19'
        in_seq_file='1k19.seq';
        in_upl_file={'1k19.upl'};
        in_ang_file='';
    case '1kun';
        in_seq_file='1kun.seq';
        in_upl_file={'1kun.upl'};
        in_ang_file='1kun.aco';
    case '1kx6'
        in_seq_file   = '1kx6.seq';
        in_upl_file   = {'1kx6.upl'};
        in_ang_file   = '';
    case '1lqh'
        in_seq_file   = '1lqh.seq';
        in_upl_file   = {'1lqh2.upl','1lqh.upl'};
        in_ang_file   = '1lqh.aco';
    case '1mm4'
        in_seq_file = '1mm4.seq';
        in_upl_file = {'1mm4.upl'};
        in_ang_file = '';
    case '1mph'
        in_seq_file = '1mph.seq';
        in_upl_file = {'1mph2.upl','1mph.upl'};
        in_ang_file = '';
    case '1mvg'
        in_seq_file='1mvg.seq';
        in_upl_file={'1mvg.upl'}; 
        in_ang_file='1mvg.aco';
    case '1n7t'
        in_seq_file='1n7t.seq';
        in_upl_file={'1n7t2.upl','1n7t.upl'};
        in_ang_file='1n7t.aco';
    case '1nmv'
        in_seq_file='1nmv.seq';
        in_upl_file={'1nmv2.upl','1nmv.upl'};
        in_ang_file='1nmv.aco';
    case '1oca'
        in_seq_file='1oca.seq';
        in_upl_file={'1oca.upl'};
        in_ang_file='';
    case '1pfl'
        in_seq_file='1pfl.seq';
        in_upl_file={'1pfl2.upl','1pfl.upl'};
        in_ang_file='1pfl.aco';
    case '1pqx'
        in_seq_file='1pqx.seq';
        in_upl_file={'1pqx2.upl','1pqx.upl'};
        in_ang_file='1pqx.aco';
    case '1qqv'
        in_seq_file='1qqv.seq';
        in_upl_file={'1qqv2.upl','1qqv.upl'};
        in_ang_file='1qqv.aco';
    case '1tbd';
        in_seq_file='1tbd.seq';
        in_upl_file={'1tbd2.upl','1tbd.upl'};
        in_ang_file='1tbd.aco';
    case '1v6r'
        in_seq_file   = '1v6r.seq';
        in_upl_file   = {'1v6r.upl'};
        in_ang_file   = '';
    case '1xga'
        in_seq_file   = '1xga.seq';
        in_upl_file   = {'1xga.upl'};
        in_ang_file   = '';
    case '1xpw'
        in_seq_file = '1xpw.seq';
        in_upl_file = {'1xpw.upl'};
        in_ang_file = '1xpw.aco';
    case '2czn'
        in_seq_file = '2czn.seq';
        in_upl_file = {'2czn2.upl','2czn.upl'};
        in_ang_file = '2czn.aco';
    case '2evn'
        in_seq_file='2evn.seq';
        in_upl_file={'2evn2.upl','2evn.upl'}; 
        in_ang_file='2evn.aco';
    case '2gpq'
        in_seq_file='2gpq.seq';
        in_upl_file={'2gpq2.upl','2gpq.upl'};
        in_ang_file='2gpq.aco';
    case '2jn8'
        in_seq_file='2jn8.seq';
        in_upl_file={'2jn82.upl','2jn8.upl'};
        in_ang_file='2jn8.aco';
    case '2ju3'
        in_seq_file='2ju3.seq';
        in_upl_file={'2ju3.upl'};
        in_ang_file='2ju3.aco';
    case '2p3m';
        in_seq_file='2p3m.seq';
        in_upl_file={'2p3m2.upl','2p3m.upl'};
        in_ang_file='2p3m.aco';
    case '3hsf'
        in_seq_file   = '3hsf.seq';
        in_upl_file   = {'3hsf.upl'};
        in_ang_file   = '3hsf.aco';
    case '3mef'
        in_seq_file   = '3mef.seq';
        in_upl_file   = {'3mef2.upl','3mef.upl'};
        in_ang_file   = '3mef.aco';
    case '6i1b'
        in_seq_file   = '6i1b.seq';
        in_upl_file   = {'6i1b2.upl','6i1b.upl'};
        in_ang_file   = '6i1b.aco';
    case '1bvm'
        in_seq_file   = '1bvm.seq';
        in_upl_file   = {'1bvm2.upl','1bvm.upl'};
        in_ang_file   = '1bvm.aco';
    case '1djm'
        in_seq_file   = '1djm.seq';
        in_upl_file   = {'1djm2.upl','1djm.upl'};
        in_ang_file   = '1djm.aco';
    case '1g9e'
        in_seq_file   = '1g9e.seq';
        in_upl_file   = {'1g9e.upl'};
        in_ang_file   = '';
    case '1kot'
        in_seq_file   = '1kot.seq';
        in_upl_file   = {'1kot.upl'};
        in_ang_file   = '';
    case '1ly7'
        in_seq_file   = '1ly7.seq';
        in_upl_file   = {'1ly7.upl'};
        in_ang_file   = '1ly7.aco';
    case '1pu3'
        in_seq_file   = '1pu3.seq';
        in_upl_file   = {'1pu32.upl','1pu3.upl'};
        in_ang_file   = '1pu3.aco';
    case '1qnd'
        in_seq_file   = '1qnd.seq';
        in_upl_file   = {'1qnd.upl'};
        in_ang_file   = '1qnd.aco';
    case '1ssn'
        in_seq_file   = '1ssn.seq';
        in_upl_file   = {'1ssn.upl'};
        in_ang_file   = '1ssn.aco';
    case '1tr4'
        in_seq_file   = '1tr4.seq';
        in_upl_file   = {'1tr42.upl','1tr4.upl'};
        in_ang_file   = '1tr4.aco';
    case '2h60'
        in_seq_file   = '2h60.seq';
        in_upl_file   = {'2h602.upl','2h60.upl'};
        in_ang_file   = '2h60.aco';
    case '2ijy'
        in_seq_file   = '2ijy.seq';
        in_upl_file   = {'2ijy2.upl','2ijy.upl'};
        in_ang_file   = '2ijy.aco';
    case '2jpb'
        in_seq_file   = '2jpb.seq';
        in_upl_file   = {'2jpb.upl'};
        in_ang_file   = '';
    case '2jps'
        in_seq_file   = '2jps.seq';
        in_upl_file   = {'2jps.upl'};
        in_ang_file   = '';
    case '3phy'
        in_seq_file   = '3phy.seq';
        in_upl_file   = {'3phy2.upl','3phy.upl'};
        in_ang_file   = '3phy.aco';
end


protein_path = ['proteins/' protein_name '/'];
fprintf('*************************************************************************\n');
fprintf('Protein: %s\n', protein_name);
fprintf('-Reading input files...\n')
% Reading input data
%==========================================================================
seq_file = [protein_path in_seq_file];
[seq, num] = seq_reader(seq_file);
max_res = max(num);
min_res = min(num);
    
num_upl = size(in_upl_file, 2);
upl_file = cell(1, num_upl);
for i = 1:num_upl
    upl_file{i} = [protein_path in_upl_file{i}];
end
if ~isempty(in_hbond_file)
    hbond_file = [protein_path in_hbond_file];
    hbond_write_file = [protein_path protein_name '_hbo.upl'];
    hbond_reader(hbond_file,hbond_write_file);
    num_upl = num_upl + 1;
    upl_file{num_upl} = hbond_write_file;
end
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
raw_up    = cell(1, num_upl);
raw_up_ho = cell(1, num_upl);
temp_min_res = +inf;
temp_max_res = -inf;
for i = 1:num_upl
    raw_up{i} = dist_reader(upl_file{i}, A);
    temp_min_res = min(temp_min_res, min([raw_up{i}.tres raw_up{i}.sres]));
    temp_max_res = max(temp_max_res, max([raw_up{i}.tres raw_up{i}.sres]));
end
if isempty(in_min_res)
    min_res = max(temp_min_res-1, min_res);
else
    min_res = in_min_res;
end
if isempty(in_max_res)
    max_res = min(temp_max_res+1, max_res);
else
    max_res = in_max_res;
end
    
% Remove informationless (w/o any constraints)
% parts from and N- and C-terminus
ind_del_N = num < min_res;
ind_del_C = num > max_res;
ind_del   = ind_del_N | ind_del_C;
seq(ind_del) = [];
num(ind_del) = [];
    
% dihedral angle constraints
ang_file = [protein_path in_ang_file];
[phi_cons, psi_cons] = ang_reader(ang_file, num);
%==========================================================================
trend = toc(tstart);
fprintf('\tdone: %4.1f sec\n', trend)
fprintf('-Sampling a random molecule...\n')
% Generating a random structure
%==========================================================================
[phi, psi] = ang_sampler(seq,phi_cons,psi_cons);

 [rand_X, Comp] = ibuildprot(seq,num,phi,psi,A);
 [U, Comp.cliq_dims] = reducer(rand_X,Comp); 
if exist(ang_file, 'file')
    [ang_lo_cons, ang_up_cons] = ang_dist_conmaker(phi_cons,psi_cons,Comp);
end

%    20180814
ang_up_intitial=ang_up_cons;
for i=1:size(ang_lo_cons,1)
    ang_up_intitial(i,3)=max(ang_up_cons(i,3)*0.8,(ang_up_cons(i,3)+ang_lo_cons(i,3))/2);
end
%==========================================================================
trand = toc(tstart);
fprintf('\tdone: %4.1f sec\n',trand - trend)
fprintf('-Forming constraints...\n')
% Generating upper and lower bounds constraints
%==========================================================================
start = 0;
up_bounds = nan(50000,4);
for i = 1:num_upl
    temp_upl = upper_maker(raw_up{i}, Comp);
    up_bounds(start+1:start+size(temp_upl,1),:) = temp_upl;
    start = start + size(temp_upl,1);
end
up_bounds(isnan(up_bounds(:,1)), :) = [];
% adding torsion-angle constraints
if exist(ang_file, 'file')
   up_bounds = [up_bounds; ang_up_intitial];
end
    
 % equality cons
 eq_cons = equality_cons_former(rand_X,Comp);
 % vdw bounds
 vdw_bounds = vdw_bound_maker(Comp);
    
 lo_bounds     = vdw_bounds;
 if exist(ang_file, 'file')
    lo_bounds    = [lo_bounds; ang_lo_cons];
end
%=========================================================================
% %
num_atom=size(Comp.atom_names,1);
cons_column=[eq_cons;up_bounds(:,1:3)];
ori_d=sparse(cons_column(:,1),cons_column(:,2),cons_column(:,3),num_atom,num_atom);
ori_d=full(ori_d);
d=ori_d+ori_d';
tbounds = toc(tstart);
fprintf('\tdone: %4.1f sec\n',tbounds - trand)
fprintf('Forming Triangle inequality constraint...\n')
fprintf('\n');

run_num=1;
while run_num<=total_run_num

Dtri= tri3stri(d);
% Dtri=tri3stri2(d);
% Dtri_intitial=Dtri;     % **********20180814
% n_Dtri=size(Dtri,1);
% for i=1:n_Dtri
%     for j=1:n_Dtri
%         if d(i,j)~=0
%             Dtri_intitial(i,j)=Dtri(i,j);
%         end
%     end
% end
ttriang = toc(tstart);
fprintf('\tdone: %4.1f sec\n',ttriang - tbounds)
disp('*********************************************************************')
sample_rate = 10*5/num_atom;

%[Dret,Dretsample ] = triChange(Dtri_intitial, d,num_atom ); % 0814
[Dret,Dretsample ] = triChange( Dtri, d,num_atom );

Drecover = randmsamplesym(Dretsample,sample_rate);
DrecoverF = Drecover+d;
DrecoverF2=DrecoverF.^2;
% %
% scaledASD
ttriang_then = toc(tstart);
fprintf('solving the MC problem by ASD...\n')
fprintf('\n');
opts = default_opts();
[m,n]=size(DrecoverF2);
r=5;
[II,JJ]=find(DrecoverF2);
Omega2=sub2ind([m,n],II,JJ);
data2=DrecoverF2(Omega2);
% start2 = make_start_x('ASD',m,n,r,Omega2,data2);
% [Mout2, Out2] = ASD(m,n,r,Omega2,data2,start2,opts);
start2 = make_start_x('ScaledASD',m,n,r,Omega2,data2);
[Mout2, Out2] =ScaledASD(m,n,r,Omega2,data2,start2,opts);
tcompu_end = toc(tstart);
fprintf('\tdone: %4.1f sec\n',tcompu_end - ttriang_then)
disp('*********************************************************************')
%==========================================================================
% Post-processing
%==========================================================================
% ASD_post_processing
fprintf('Post processing...\n')
fprintf('\n');
H=eye(num_atom)-ones(num_atom,num_atom)/num_atom;
G2=-1/2*H*Mout2*H;
[VZ2,LZ2]=eigb(G2);
LZ2=real(LZ2);
LZ2(LZ2<0)=0;
Z2=LZ2^0.5*VZ2';
rawX=Z2(1:3,:); 
disp('*********************************************************************')
% Analysis of the output
%==========================================================================
fprintf('Violations (raw)\n')
check_eq_cons =eq_cons;

%add tri
[tri1,tri2,tri3]=find(Drecover);
tri4=zeros(size(tri1,1),1);
bondtri=[tri1 tri2 tri3 tri4];
up_bounds=[up_bounds;bondtri];

report = protchecker(rawX(1:3,:),Comp,check_eq_cons,lo_bounds,up_bounds,1);
disp('*********************************************************************')
%==========================================================================
% Post-processing
%==========================================================================
fprintf('Post-Processing...\n')
fprintf('\n');
f = [10 10 10 10 10];
W = [2 1 1 -1];

% Phase I - GD
% Refinement by HANSO
[pX, hinfo] = hanso_post_processing(rand_X, rawX, Comp, lo_bounds, up_bounds, W, f);
fprintf('Violations (GD-I)\n')
p_report = protchecker(pX,Comp,check_eq_cons,lo_bounds,up_bounds,1);
%---------------------------------------------------------------------------
% simple fix using the fact that most residues lie on the left half of
% Ramachandran plot
if sum(p_report.phi(~isnan(p_report.phi)) > 0) > 0.5*length(p_report.phi)
    pX(1,:) = -pX(1,:);
end
p_report = protchecker(pX,Comp,check_eq_cons,lo_bounds,up_bounds,0);
fprintf('\nCorrecting chiralities:\n')
pXc = chirality_correction(pX,Comp,p_report.chiral);
fprintf('Violations (after fixing chiralities)\n')
p_report = protchecker(pXc,Comp,check_eq_cons,lo_bounds,up_bounds,1);
disp('*********************************************************************')

[pXc, c_info] = hanso_post_processing(rand_X,pXc,Comp,lo_bounds,up_bounds,W,f);
fprintf('Violations (GD-II)\n')
pc_report = protchecker(pXc,Comp,check_eq_cons,lo_bounds,up_bounds,1);
fprintf('\nCorrecting chiralities:\n')
pXc = chirality_correction(pXc,Comp,pc_report.chiral);
disp('*********************************************************************')
[fX, wh_info] = hanso_post_processing(rand_X,pXc,Comp,lo_bounds,up_bounds,W,f);
 fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
 fprintf('\nViolations (FINAL)\n')
 fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
 final_report = protchecker(fX,Comp,check_eq_cons,lo_bounds,up_bounds,1);
 disp('*********************************************************************')
%==========================================================================


tpost_end = toc(tstart);
fprintf('\tdone: %4.1f sec\n',tpost_end-tcompu_end)
disp('*********************************************************************')
fprintf('\n Writing pdb\n')
a=num2str(run_num);
pdb_writer_file=['' protein_name '' a '.pdb'];
pdb_writer(pdb_writer_file,fX,Comp)
twrite_end = toc(tstart);
fprintf('\tdone: %4.1f sec\n',twrite_end-tpost_end)
fprintf('==========================================================================\n')
fprintf('\tOverall time: %4.1f sec\n',toc(tstart))

run_num=run_num+1;
end

 end
fprintf('done!\n')
fprintf('==========================================================================\n')
