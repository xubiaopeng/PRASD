function PRASD(protein_pathway,protein_name,in_min_res,in_max_res,output_pathway,algorithm)
% mac; linux

if isdeployed
  %fid = fopen(fullfile(ctfroot,'myfolder','myfile.dat'))
  mydir = ctfroot ;
%end
in_min_res=str2num(in_min_res);
in_max_res=str2num(in_max_res);
addpath([mydir '/code/helperfunctions']);
addpath([mydir '/code/inputreaders']);
addpath([mydir '/code/sdpstuff']);
addpath([mydir '/code/refinement']);
addpath([mydir '/hanso']);
addpath([mydir '/tt']);
addpath([mydir '/code/refinement']);
addpath([mydir '/matrix_completion/Auxiliary']);
addpath([mydir '/matrix_completion/Main']);
%load([mydir '/ainfo.mat']);
end
load 'ainfo.mat'


hydrogen_omission = 0;


% Number of BFGS iterations
gd_tol  = 10^-9;
cg_iter = 500;
f = [10 10 10 10 10]; % [f_hb, f_tau, f_tal, f_vdw, f_tas]



fprintf('==========================================================================\n')
fprintf('------------SPROS: SDP-based Protein Structure Determination--------------\n')



tstart = tic;

in_hbond_file = '';

in_seq_file   = [protein_name '.seq'];
in_upl_file   = {[protein_name '.upl']};
in_ang_file   = [protein_name '.aco'];

protein_path = [ protein_pathway '/' protein_name '/'];
fprintf('*************************************************************************\n');
fprintf('Protein: %s\n', protein_name);
fprintf('-Reading input files...\n')
% Reading input data
%==========================================================================
seq_file = [protein_path in_seq_file];
[seq, num] = seq_reader(seq_file);
max_res = max(num);
min_res = min(num);
    
num_upl = size(in_upl_file, 2);
upl_file = cell(1, num_upl);
for i = 1:num_upl
    upl_file{i} = [protein_path in_upl_file{i}];
end
if ~isempty(in_hbond_file)
    hbond_file = [protein_path in_hbond_file];
    hbond_write_file = [protein_path protein_name '_hbo.upl'];
    hbond_reader(hbond_file,hbond_write_file);
    num_upl = num_upl + 1;
    upl_file{num_upl} = hbond_write_file;
end
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
raw_up    = cell(1, num_upl);
raw_up_ho = cell(1, num_upl);
temp_min_res = +inf;
temp_max_res = -inf;
for i = 1:num_upl
    raw_up{i} = dist_reader(upl_file{i}, A);
    temp_min_res = min(temp_min_res, min([raw_up{i}.tres raw_up{i}.sres]));
    temp_max_res = max(temp_max_res, max([raw_up{i}.tres raw_up{i}.sres]));
end
if isempty(in_min_res)
    min_res = max(temp_min_res-1, min_res);
else
    min_res = in_min_res;
end
if isempty(in_max_res)
    max_res = min(temp_max_res+1, max_res);
else
    max_res = in_max_res;
end
    
% Remove informationless (w/o any constraints)
% parts from and N- and C-terminus
ind_del_N = num < min_res;
ind_del_C = num > max_res;
ind_del   = ind_del_N | ind_del_C;
seq(ind_del) = [];
num(ind_del) = [];
    
% dihedral angle constraints
ang_file = [protein_path in_ang_file];
[phi_cons, psi_cons] = ang_reader(ang_file, num);
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
pdb_write_file = [protein_path protein_name '.pdb'];
%==========================================================================
trend = toc(tstart);
fprintf('\tdone: %4.1f sec\n', trend)
fprintf('-Sampling a random molecule...\n')
% Generating a random structure
%==========================================================================
[phi, psi] = ang_sampler(seq,phi_cons,psi_cons);

 [rand_X, Comp] = ibuildprot(seq,num,phi,psi,A);
 
 [U, Comp.cliq_dims] = reducer(rand_X,Comp);
 
 wh_rand_X = rand_X;
 wh_Comp   = Comp;
 
if exist(ang_file, 'file')
    [ang_lo_cons, ang_up_cons] = ang_dist_conmaker(phi_cons,psi_cons,wh_Comp);
end
%==========================================================================
fprintf('-Forming constraints...\n')
% Generating upper and lower bounds constraints
%==========================================================================
start = 0;
wh_up_bounds = nan(50000,4);
for i = 1:num_upl
    temp_upl = upper_maker(raw_up{i}, wh_Comp);
    wh_up_bounds(start+1:start+size(temp_upl,1),:) = temp_upl;
    start = start + size(temp_upl,1);
end
wh_up_bounds(isnan(wh_up_bounds(:,1)), :) = [];


% adding torsion-angle constraints
if exist(ang_file, 'file')
    wh_up_bounds = [wh_up_bounds; ang_up_cons];
    wh_sdp_lo_bounds = ang_lo_cons;
end
    
 % equality cons
 wh_eq_cons = equality_cons_former(rand_X,Comp);
 eq_cons = wh_eq_cons;
 % upper bounds
 up_bounds = wh_up_bounds;
 % vdw bounds
 wh_vdw_bounds = vdw_bound_maker(wh_Comp);
 vdw_bounds    = wh_vdw_bounds;
 sdp_lo_bounds = wh_sdp_lo_bounds;

    
lo_bounds     = vdw_bounds;
wh_lo_bounds  = wh_vdw_bounds;
if ~exist('sdp_lo_bounds', 'var')
    sdp_lo_bounds = [];
else
    lo_bounds    = [lo_bounds; sdp_lo_bounds];
    wh_lo_bounds = [wh_lo_bounds; wh_sdp_lo_bounds];
end
%=========================================================================
% %
num_atom=size(wh_Comp.atom_names,1);
cons_column=[wh_eq_cons;wh_up_bounds(:,1:3)];
ori_d=sparse(cons_column(:,1),cons_column(:,2),cons_column(:,3),num_atom,num_atom);
ori_d=full(ori_d);
d=ori_d+ori_d';
htttt=min(max(d));
tbounds = toc(tstart);
fprintf('\tdone: %4.1f sec\n',tbounds - trend)
fprintf('Forming Triangle inequality constraint...\n')
fprintf('\n');
%Dtri= tri3strixubiao(d,Comp);
Dtri= tri3stri(d);
ttriang = toc(tstart);
fprintf('\tdone: %4.1f sec\n',ttriang - tbounds)
disp('*********************************************************************')
sample_rate = 10*5/num_atom;
[Dret,Dretsample ] = triChange( Dtri, d,num_atom );
Drecover = randmsamplesym(Dretsample,sample_rate);
DrecoverF = Drecover+d;
DrecoverF2=DrecoverF.^2;
% %
% scaledASD
ttriang_then = toc(tstart);
opts = default_opts();
[m,n]=size(DrecoverF2);
r=5;
[II,JJ]=find(DrecoverF2);
Omega2=sub2ind([m,n],II,JJ);
data2=DrecoverF2(Omega2);
% start2 = make_start_x('ASD',m,n,r,Omega2,data2);
% [Mout2, Out2] = ASD(m,n,r,Omega2,data2,start2,opts);
if strcmp(algorithm,'ASD')
fprintf('solving the MC problem by ASD...\n')
fprintf('\n');
start2 = make_start_x('ASD',m,n,r,Omega2,data2);
[Mout2, Out2] =ASD(m,n,r,Omega2,data2,start2,opts);
elseif strcmp(algorithm,'ScaledASD')
fprintf('solving the MC problem by ScaledASD...\n')
fprintf('\n');
start2 = make_start_x('ScaledASD',m,n,r,Omega2,data2);
[Mout2, Out2] =ScaledASD(m,n,r,Omega2,data2,start2,opts);
else
display('Input parameters error! Please select correct algorithm: ASD or ScaledASD');
exit(1);    
end
tcompu_end = toc(tstart);
fprintf('\tdone: %4.1f sec\n',tcompu_end - ttriang_then)
disp('*********************************************************************')
%==========================================================================
% Post-processing
%==========================================================================
% ASD_post_processing
fprintf('Post processing...\n')
fprintf('\n');
H=eye(num_atom)-ones(num_atom,num_atom)/num_atom;
G2=-1/2*H*Mout2*H;
[VZ2,LZ2]=eigb(G2);
LZ2=real(LZ2);
LZ2(LZ2<0)=0;
Z2=LZ2^0.5*VZ2';
rawX=Z2(1:3,:); 
disp('*********************************************************************')
% Analysis of the output
%==========================================================================
fprintf('Violations (raw)\n')
check_eq_cons =eq_cons;

%add tri
[tri1,tri2,tri3]=find(Drecover);
tri4=zeros(size(tri1,1),1);
bondtri=[tri1 tri2 tri3 tri4];
up_bounds=[up_bounds;bondtri];


report = protchecker(rawX(1:3,:),Comp,check_eq_cons,lo_bounds,up_bounds,1);
disp('*********************************************************************')
%==========================================================================
% Post-processing
%==========================================================================
fprintf('Post-Processing...\n')
fprintf('\n');
f = [10 10 10 10 10];
W = [2 1 1 -1];

% Phase I - GD
% Refinement by HANSO

[pX, hinfo] = hanso_post_processing(rand_X, rawX, Comp, lo_bounds, up_bounds, W, f);
fprintf('Violations (GD-I)\n')
p_report = protchecker(pX,Comp,check_eq_cons,lo_bounds,up_bounds,1);
%---------------------------------------------------------------------------
% simple fix using the fact that most residues lie on the left half of
% Ramachandran plot
if sum(p_report.phi(~isnan(p_report.phi)) > 0) > 0.5*length(p_report.phi)
    pX(1,:) = -pX(1,:);
end
p_report = protchecker(pX,Comp,check_eq_cons,lo_bounds,up_bounds,0);
fprintf('\nCorrecting chiralities:\n')
pXc = chirality_correction(pX,Comp,p_report.chiral);
fprintf('Violations (after fixing chiralities)\n')
p_report = protchecker(pXc,Comp,check_eq_cons,lo_bounds,up_bounds,1);
disp('*********************************************************************')

[pXc, c_info] = hanso_post_processing(rand_X,pXc,Comp,lo_bounds,up_bounds,W,f);
fprintf('Violations (GD-II)\n')
pc_report = protchecker(pXc,Comp,check_eq_cons,lo_bounds,up_bounds,1);
fprintf('\nCorrecting chiralities:\n')
pXc = chirality_correction(pXc,Comp,pc_report.chiral);
disp('*********************************************************************')
[fX, wh_info] = hanso_post_processing(rand_X,pXc,Comp,lo_bounds,up_bounds,W,f);
 fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
 fprintf('\nViolations (FINAL)\n')
 fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
 final_report = protchecker(fX,Comp,check_eq_cons,lo_bounds,up_bounds,1);
 disp('*********************************************************************')
%==========================================================================


tpost_end = toc(tstart);
fprintf('\tdone: %4.1f sec\n',tpost_end-tcompu_end)
disp('*********************************************************************')
fprintf('\n Writing pdb\n')
%pdb_writer(['1cn7_3.pdb'],fX,Comp)
pdb_writer([output_pathway '/' protein_name '.pdb'],fX,Comp)
twrite_end = toc(tstart);
fprintf('\tdone: %4.1f sec\n',twrite_end-tpost_end)
fprintf('==========================================================================\n')
fprintf('\tOverall time: %4.1f sec\n',toc(tstart))
fprintf('done!\n')
fprintf('==========================================================================\n')
end